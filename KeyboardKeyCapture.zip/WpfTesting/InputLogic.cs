﻿using System;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfTesting
{
    public class InputLogic
    {
        public string keyPressed;       // Save name of key pressed
        public string keyPressedID;     // Save ID of key pressed as a string
        public int keyId;               // Save ID of key pressed as an int

        public void InputPreviewKeyDown(object sender, KeyEventArgs e)
        {
            keyId = (int)e.Key;
            if (keyId >= 19 && keyId <= 32 || e.Key == Key.Back)
            {
                e.Handled = true;
            }
            else if (e.Key == Key.Enter)
            {
                e.Handled = true;
            }
            else if ((int)e.Key >= 140 && (int)e.Key <= 154)
            {
                e.Handled = false;
            }
        }

        public void TextInputKeyDown(object sender, KeyEventArgs e, TextBox textBox)
        {
            keyPressed = Convert.ToString(e.Key);
            keyPressedID = Convert.ToString((int)e.Key);

            if ((int)e.Key >= 34 && (int)e.Key <= 43)
            {
                textBox.Text = keyPressed.Remove(0, 1);
                keyPressed = keyPressed.Remove(0, 1);
            }
            else if (e.Key == Key.Capital)
            {
                textBox.Text = "Caps Lock";
            }
            else
            {
                textBox.Text = keyPressed;
            }
        }

        public void InputBoxKeyUp(object sender, KeyEventArgs e, TextBox textBox)
        {
            keyPressedID = Convert.ToString(keyId);

            if (keyId >= 19 && keyId <= 32 || e.Key == Key.Back || e.Key == Key.Space)
            {
                if (keyId == 20)
                {
                    keyPressed = "PageDown";
                    textBox.Text = keyPressed;
                }
                else
                {
                    keyPressed = Convert.ToString(e.Key);
                    textBox.Text = keyPressed;
                }
            }
        }

        public void PreviewTextInput(object sender, TextCompositionEventArgs e, TextBox textBox)
        {
            foreach (var ch in e.Text)
            {
                if ((Char.IsPunctuation(ch)) || Char.IsSymbol(ch))
                {
                    textBox.Text = e.Text;
                    keyPressed = e.Text;
                    break;
                }
            }
        }
    }
}
