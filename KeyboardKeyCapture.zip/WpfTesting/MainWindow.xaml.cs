﻿using System;
using System.Windows;
using System.Windows.Input;

namespace WpfTesting
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        InputLogic inputLogic = new InputLogic();

        //PreviewTextInput event handler
        private void inputBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            inputLogic.InputPreviewKeyDown(sender, e);

            // If Enter key is pressed, call submitButton_Click method instead of display Enter
            if (e.Key == Key.Enter)
            {
                submitButton_Click(sender, e);
            }
        }

        // KeyDown event handler
        // Add name of key to text box from KeyDown event handler
        private void OnTextInputKeyDown(object sender, KeyEventArgs e)
        {
            inputLogic.TextInputKeyDown(sender, e, inputBox);
        }

        // KeyUp event handler
        // Add name of key to text box from KeyUp event handler
        private void inputBox_KeyUp(object sender, KeyEventArgs e)
        {
            inputLogic.InputBoxKeyUp(sender, e, inputBox);           
        }

        // PreviewKeyDown event handler
        // Add name of key to text box from PreviewKeyDwon event handler
        private void inputBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            inputLogic.PreviewTextInput(sender, e, inputBox);
        }

        // Submit button method to display Key typed and Key ID 
        private void submitButton_Click(object sender, RoutedEventArgs e)
        {
            displayButtonText.Text = inputLogic.keyPressed;
            displayButtonId.Text = inputLogic.keyPressedID;
        }

    }
}
